import styles from "./AboutImage.module.css";

export default function AboutImage() {
  return <div className={styles.image}></div>;
}
