import styles from "./AboutTitle.module.css";

export default function AboutTitle() {
  return <h1 className={styles.title}>About me.</h1>;
}
