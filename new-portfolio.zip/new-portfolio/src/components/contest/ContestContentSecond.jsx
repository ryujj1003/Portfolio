import styles from "./ContestContentItem.module.css";

export default function ContestConentSecond() {
  return (
    <div className={styles.item}>
      <div className={styles.img2}></div>
      <div className={styles.box}>
        <div className={styles.text}>
          <h1>한이음 멘토멘티 프로젝트</h1>
          <br></br>
          <br></br>
          <p>이런 이런 역할 이런 저런 역할 이런 저런걸 만들었음</p>
        </div>
      </div>
    </div>
  );
}
