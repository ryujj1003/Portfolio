import styles from "./ContestContentItem.module.css";
export default function ContestContentThird() {
  return (
    <div className={styles.item}>
      <div className={styles.box}>
        <div className={styles.text}>
          <h1>Junction Asia</h1>
          <br></br>
          <br></br>
          <p>프론트 엔드 개발자 역할을 맡음</p>
        </div>
      </div>
      <div className={styles.img3}></div>
    </div>
  );
}

///DKASDFASDF
