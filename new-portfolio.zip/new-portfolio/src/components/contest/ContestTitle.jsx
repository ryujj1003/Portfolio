import styles from "./ContestTitle.module.css";

export default function ContestTitle() {
  return (
    <div className={styles.title}>
      <h1>Contest</h1>
    </div>
  );
}
