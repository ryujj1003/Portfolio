import styles from './Background.module.css';
import React from 'react';

function Background() {
    return <div className={styles.bg}>Background</div>;
}

export default Background;
