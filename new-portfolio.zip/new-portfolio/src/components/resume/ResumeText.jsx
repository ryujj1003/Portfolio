import styles from "./ResumeText.module.css";

export default function ResumeText() {
  return (
    <div>
      <h1 className={styles.title}>Resume</h1>
    </div>
  );
}
