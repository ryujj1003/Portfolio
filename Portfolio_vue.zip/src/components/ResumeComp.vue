<template>
    <section id="resume" class="resume-container">
        <div class="resume-box">
            <div class="resume-title">Resume</div>
            <div>
                <img class="resume-img" src="@/assets/img/resume.png" />
            </div>
        </div>
    </section>
</template>
<style scoped>
@import "@/assets/css/resume.css";
</style>