<script setup>
const props = defineProps(['title','subtitle','mail','imagesrc','textalign']);
</script>
<template>
    <div class="project-title-box">
        <div class="project-title-main">
            <div :style="{'text-align':props.textalign}">{{ props.title }}</div>            
        </div>
        <div class="project-title-sub">
            <div :style="{'text-align':props.textalign}">
                <p>{{ props.subtitle }}</p>
                <p>{{ props.mail }}</p>
            </div>
        </div>     
        <div class="project-title-img">
            <div class="img" :style="{'background-image':'url('+props.imagesrc+')'}"></div>
        </div>
    </div>
</template>