<template>
    <header class="header-container">
        <div class="header-box">
            <div class="header-title">RJJ Portfolio</div>
            <div class="header-option">
                <a v-scroll-to="{ element: '#home', duration: 500 }">Home</a>
                <a v-scroll-to="{ element: '#about', duration: 500 }">About</a>
                <a v-scroll-to="{ element: '#resume', duration: 500 }">Resume</a>
                <a v-scroll-to="{ element: '#projects', duration: 500 }">Projects</a>
                <a v-scroll-to="{ element: '#contest', duration: 500 }">Contest</a>
                <a v-scroll-to="{ element: '#career', duration: 500 }">Career</a>
            </div>
        </div>
    </header>
</template>
<style scoped>
@import "@/assets/css/header.css";
</style>
