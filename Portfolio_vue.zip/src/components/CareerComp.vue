<template>
    <section id="career" class="career-container">
        <div class="career-box">
            <div class="career-title">Career</div>
            <div class="career-text">
                <div class="career-year">2023</div>
                <div>
                    우아한 테크 코스 7기 시작 <br/>
                    봉사활동
                </div>
            </div>
            <div class="line"></div>
            <div class="career-text">
                <div class="career-year">2024</div>
                <div>
                    우아한 테크 코스 7기 종료 <br/>
                    당근 인턴
                </div>
            </div>
            <div class="line"></div>
            <div class="career-text">
                <div class="career-year">2025</div>
                <div>
                    (주)네이버 프론트엔드 개발자 취업
                </div>
            </div>
            <div class="line"></div>
            <div class="career-text">
                <div class="career-year">ing...</div>
            </div>
        </div>
    </section>
</template>
<style scoped>
@import "@/assets/css/career.css";
</style>