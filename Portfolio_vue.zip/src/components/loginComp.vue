<script>
export default{
    data(){
        return {
            id: "",
            pass: ""
        }
    },
    methods : {
        validCheck(){
            if(this.id === "1234" && this.pass === "1234"){
                location.href="/main"
            }else{
                alert("아이디 혹은 비밀번호가 잘못되었습니다");
            }
        }
    }
}
</script>
<template>
    <section class="login-container">
        <div class="login-box">
            <form class="login-form">
                <h3 class="login-title">로그인</h3>
                <div class="input-field">
                    <label>아이디</label>
                    <input v-model="id"/>
                </div>
                <div class="input-field">
                    <label>비밀번호</label>
                    <input type="password" v-model="pass"/>
                </div>
                <button type="button" class="button" @click="validCheck">
                    로그인
                </button>
            </form>
        </div>
    </section>
</template>
<style scoped>
@import "../assets/css/login.css";
</style>