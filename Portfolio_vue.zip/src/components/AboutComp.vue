<script setup>
import AboutCompLeft from './AboutCompLeft.vue';
import AboutCompRight from './AboutCompRight.vue';
</script>
<template>
    <section id="about" class="about-container">
        <div class="about-box">
            <AboutCompLeft></AboutCompLeft>
            <AboutCompRight></AboutCompRight>
        </div>
    </section>
</template>
<style scoped>
@import "@/assets/css/about.css";
</style>