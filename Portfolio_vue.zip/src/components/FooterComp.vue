<template>
    <div id="footer">
        <i>
            Copyright 2023. 지은이 all right reserved.
            <br/>
            연락처 : 010-8906-3946
        </i>
    </div>
</template>