<script setup>
import ContestCompBox from './ContestCompBox.vue';
</script>
<template>
    <section id="contest" class="contest-container">
        <div class="main-title">Contest</div>
        <div class="contest-itmes-box">
            <ContestCompBox 
                title="K-HACKATHON"
                content="자율주행 배달로봇 플랫폼 벡엔드 개발 담당">
            </ContestCompBox>
            <div class="box-img" style="background-image: url('src/assets/img/hackertom.png');"></div>
        </div>
        <div class="contest-itmes-box">
            <div class="box-img" style="background-image: url('src/assets/img/hamaum.png');"></div>
            <ContestCompBox 
                title="한이음 멘토멘티 프로젝트"
                content="이런 역할 저런 역할 이런 저런걸 만들었음">
            </ContestCompBox>
        </div>
        <div class="contest-itmes-box">
            <ContestCompBox 
                title="Junction Asia"
                content="프론트 엔드 개발자 역할을 맡음">
            </ContestCompBox>
            <div class="box-img" style="background-image: url('src/assets/img/hackthe.jpg');"></div>
        </div>
        
    </section>
</template>

<style scoped>
@import "@/assets/css/contest.css";
</style>