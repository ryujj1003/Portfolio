<script setup>
const props = defineProps(['title','content']);
</script>
<template>
    <div class="contest-comp-box">
        <h1>{{ props.title }}</h1>
        <p>{{ props.content }}</p>
    </div>
</template>