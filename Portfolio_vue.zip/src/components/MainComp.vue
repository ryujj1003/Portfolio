<script setup>
import AboutComp from './AboutComp.vue';
import CareerComp from './CareerComp.vue';
import ContestComp from './ContestComp.vue';
import IntroComp from './IntroComp.vue';
import ProjectComp from './ProjectComp.vue';
import ResumeComp from './ResumeComp.vue';

import HeaderComp from './HeaderComp.vue';
</script>
<template>
    <div id="index">
        <HeaderComp></HeaderComp>
        <div id="container">
            <IntroComp></IntroComp>
            <AboutComp></AboutComp>
            <ResumeComp></ResumeComp>
            <ProjectComp></ProjectComp>
            <ContestComp></ContestComp>
            <CareerComp></CareerComp>
        </div>
        
    </div>
</template>