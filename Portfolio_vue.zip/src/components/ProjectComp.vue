<script setup>
import ProjectCompContent from './ProjectCompContent.vue';
</script>
<template>
    <section id="projects" class="project-container">
        <div class="project-box container-padding">
            <div class="last-project-items">
                <div class="last-project">
                    Lastest Project
                </div>
                <ProjectCompContent 
                    title="React Project" 
                    subtitle="카카오 클론코딩" 
                    mail="www.naver.com"
                    imagesrc="src/assets/img/reac_app_project.png"
                ></ProjectCompContent>
            </div>
            <div class="line"></div>
            <div class="middel-projects">
                <ProjectCompContent 
                    textalign="left"
                    title="Vue Project" 
                    subtitle="트위터 클론코딩" 
                    mail="www.twitter.com"
                    imagesrc="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUie-bcRLJglX-fGNR9NPPIPmcnJiRPVkGVQ&usqp=CAU"
                ></ProjectCompContent>
                <ProjectCompContent 
                    textalign="right"
                    title="Node Project" 
                    subtitle="서버 코딩" 
                    mail="www.someapi.com"
                    imagesrc="https://media.geeksforgeeks.org/wp-content/uploads/20230216170349/What-is-an-API.png"
                ></ProjectCompContent>
            </div>
            <div class="line"></div>
            <div class="last-project-items">
                <ProjectCompContent 
                    title="Proxy Project" 
                    subtitle="프록시 프로젝트" 
                    mail="www.someapi.com"
                    imagesrc="https://www.researchgate.net/profile/Ahmet-Sayar/publication/261960573/figure/fig1/AS:392517750149120@1470594932033/Proposed-system-architecture-with-school-level-proxy-in-Fatih-Project.png"
                ></ProjectCompContent>
            </div>
        </div>
    </section>
</template>
<style scoped>
@import "@/assets/css/project.css";
</style>