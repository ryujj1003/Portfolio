<template>
    <div class="about-left-box">
        <div class="about-left-title">About me.</div>
        <div class="about-left-items">
            <div>
                <div class="items-title">이름</div>
                <div class="items-subtitle">류재준</div>
            </div>
            <div>
                <div class="items-title">생년월일</div>
                <div class="items-subtitle">2001.10.03</div>
            </div>
            <div>
                <div class="items-title">주소지</div>
                <div class="items-subtitle">경기도 성남시</div>
            </div>
            <div>
                <div class="items-title">연락처</div>
                <div class="items-subtitle">010-1234-5678</div>
            </div>
            <div>
                <div class="items-title">이메일</div>
                <div class="items-subtitle">ryujj1003@gmail.com</div>
            </div>
            <div>
                <div class="items-title">학력</div>
                <div class="items-subtitle">가천대학교</div>
            </div>
        </div>
    </div>
</template>
