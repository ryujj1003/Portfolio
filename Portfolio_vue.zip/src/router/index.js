import { createRouter, createWebHistory } from 'vue-router'
import MainCompVue from '@/components/MainComp.vue'
import LoginCompVue from '@/components/loginComp.vue'
// import AboutCompVue from '@/components/AboutComp.vue'
// import CareerCompVue from '@/components/CareerComp.vue'
// import ContestCompVue from '@/components/ContestComp.vue'
// import IntroCompVue from '@/components/IntroComp.vue'
// import ProjectCompVue from '@/components/ProjectComp.vue'
// import ResumeCompVue from '@/components/ResumeComp.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: LoginCompVue
    },
    {
      path:'/main',
      component: MainCompVue
    }
  ],
})

export default router
